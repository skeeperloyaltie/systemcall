// Inside time.h

#ifndef _TIME_H_
#define _TIME_H_

struct time_info {
    uint creation_time;
    uint end_time;
    uint total_time;
};

#endif // _TIME_H_
